# Kaban / Seed Keeper

Approved direction: Seed Keeper, with Bantayog Regular as the main wordmark. A broad chest contains a seed-shaped keyhole: family resources kept for tomorrow. Chestnut and ivory echo the warmth of the reference chests without reproducing their ornament.

## Files

- `svg/`: symbol, horizontal, stacked and wordmark-only artwork in chestnut, black, white and ivory. White/ivory symbols have optical compensation for dark backgrounds.
- `masters/`: standard and simplified small-size symbol masters.
- `png/`: transparent raster artwork in the same four treatments.
- `web/`: app-icon SVG, favicon SVG/ICO/PNGs, Apple touch icon, 192/512 icons, maskable icon, reference webmanifest and head snippet.
- `usage-guide.html`: printable single-page guide. `usage-guide.md` is the text version.
- `presentation.html` and `presentation/`: five-slide presentation and six consumer-app mockups. Example domains, accounts and contact details on these mockups are placeholders.
- `kaban-preview.png`: identity overview. `kaban-logo.png`: transparent chestnut horizontal logo.
- `contrast-checks.json`: calculated contrast ratios.

Use `svg/kaban-horizontal-color.svg` as the primary signature on light surfaces; use the ivory version on dark surfaces. Use the dedicated small cut at 16–31 px. The small cut simplifies the seed into a geometric keyhole and opens the lid seam. The app and web-icon tiles use that robust simplified cut consistently.

The webmanifest and head snippet are reference assets. The current app was not changed; merge icons and metadata into its existing PWA setup when implementing the identity. Do not replace an existing generated manifest blindly.

## Typeface and rights

Bantayog Regular comes from the project's `public/fonts`. The logo contains outlined letters, with no live text, font embedding, or redistributed font binaries. Do not redraw or simplify the rough letter contours. The original typeface remains its designer's work.

The author's [current licensing page](https://jadmaza.com/eula), checked 2026-11-02, permits logo use and says free commercial fonts require one licence per user/device. The project's local Bantayog notices identify a one-user free font licence. Each additional font user should obtain their own copy from the designer. This package does not grant a separate font licence.

No external trademark clearance was performed. Print CMYK values are mathematical approximations; no Pantone match or physical print proof is claimed. SVG and PNG artwork is supplied; no native AI/EPS or print PDF is included.

## Validation

Masters and lockups are parsed and checked for path-only logo content by `build.py`; primary contrast pairs exceed 4.5:1. Symbol audits and rendered checks cover standard, small and reversed variants. All five presentation slides and the app/favicon examples were rendered in Chrome and visually inspected. Original Bantayog contour complexity is intentional. Logo geometry does not claim to reproduce an authenticated traditional motif.

Rebuild masters in this repository with `python design/kaban/logo-kit/build.py` (requires the earlier outlined Bantayog study). The deliverable SVG/PNG/web files work independently of the build script. `build.py` rebuilds vector masters and presentation configuration; raster, web and presentation exports use the logo-design skill scripts separately.
